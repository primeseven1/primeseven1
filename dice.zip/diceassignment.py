import arcade
import random
import logging

SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480
SPRITE_SCALING_DIE = 1
DICELIST = ["dieRed1.png", "dieRed2.png", "dieRed3.png", "dieRed4.png", "dieRed5.png", "dieRed6.png"]


class MyGame(arcade.Window):
    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        
        self.set_mouse_visible(False)        
        arcade.set_background_color(arcade.color.CORNSILK)   
        
        self.dice_list = None        
        self.roll = False
        self.doubles = False
        self.score = 0
    
    def setup(self):
        self.dice_list = arcade.SpriteList()
        
        # You might be wondering what these two variables here are for, the problem is, I get an error when I remove it, so that's why it stays :D
        self.x = 0
        self.y = 1
        
        # Dicelist is just a list for the PNG files
        self.dice = arcade.Sprite(DICELIST[0], SPRITE_SCALING_DIE)
        self.dice2 = arcade.Sprite(DICELIST[0], SPRITE_SCALING_DIE)

        # Sets the position of the dice
        self.dice.center_x = SCREEN_WIDTH/4
        self.dice.center_y = SCREEN_HEIGHT/2
        self.dice2.center_x = self.dice.center_x*3
        self.dice2.center_y = SCREEN_HEIGHT/2

        # Adds the dice to the list
        self.dice_list.append(self.dice)
        self.dice_list.append(self.dice2)
    
    def roll_the_dice(self):
        self.x = random.randrange(0,6)
        self.y = random.randrange(0,6)

        self.dice = arcade.Sprite(DICELIST[self.x], SPRITE_SCALING_DIE)
        self.dice2 = arcade.Sprite(DICELIST[self.y], SPRITE_SCALING_DIE)

        # I did this again here because if I don't the dice will move to the bottom corner of the screen :D
        self.dice.center_x = SCREEN_WIDTH/4
        self.dice.center_y = SCREEN_HEIGHT/2
        self.dice2.center_x = self.dice.center_x*3
        self.dice2.center_y = SCREEN_HEIGHT/2
        self.dice_list.append(self.dice)
        self.dice_list.append(self.dice2)

    def on_draw(self):
        arcade.start_render()
        self.dice_list.draw()
        arcade.draw_text(f"Score: {self.score}", 50, 50, arcade.color.BLACK, 24)
        if self.doubles == True:
            arcade.draw_text("Doubles!", 270, 280, arcade.color.BLACK, 24)

        
    def update(self, delta_time):
        if self.roll == True:
            self.roll_the_dice()
        
    def on_key_press(self, key, modifiers):
        if key == arcade.key.SPACE:
            # Sets self.doubles equal to false once you press the key so that it dosen't say doubles while pressing the key
            self.doubles = False
            self.roll = True
            self.on_draw()
            
    def on_key_release(self, key, modifiers):
        if key == arcade.key.SPACE:
            self.roll = False 
            if self.x == self.y:
                self.score += 1
                self.doubles = True
    

def main():
    window = MyGame(SCREEN_WIDTH, SCREEN_HEIGHT, "Roll the Dice")       
    window.setup() 
    arcade.run()
main()